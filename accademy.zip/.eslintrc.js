// .eslintrc.js
module.exports = {
    rules: {
        "vue/no-deprecated-slot-attribute": "off",
    },
};
