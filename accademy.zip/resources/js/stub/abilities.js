const abilities = {
    CREATE_USER: "create_user",
    EDIT_USER: "edit_user",
    DELETE_USER: "delete_user",
    VIEW_USER: "view_user",
    LIST_USER: "list_user",
    CREATE_COURSE: "create_course",
    EDIT_COURSE: "edit_course",
    DELETE_COURSE: "delete_course",
    VIEW_COURSE: "view_course",
    LIST_LESSON: "list_lesson",
    CREATE_LESSON: "create_lesson",
    EDIT_LESSON: "edit_lesson",
    DELETE_LESSON: "delete_lesson",
    VIEW_LESSON: "view_lesson",
    LIST_LESSON: "list_lesson",
};

export default abilities;
