<template>
    <div class="flex flex-col space-y-3 xl:flex-row xl:space-x-4 xl:space-y-0 xl:items-center">
        <slot></slot>
    </div>
</template>
